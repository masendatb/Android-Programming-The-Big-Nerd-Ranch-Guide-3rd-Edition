package com.bignerdrange.android.geoquiz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
//import android.view.Gravity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button mTrueButton;
    private Button mFalseButton;
    private Button mNextButton;
    private Button mPrevButton;
    private TextView mQuestionTextView;

    private static final String TAG = "MainActivity";
    private static final String KEY_INDEX = "index";
    private static final String QUESTION_ANSWERED = "question_answered";

    //create an array of Question objects
    private Question[] mQuestionBank = new Question[]{
            new Question(R.string.question_australia,true),
            new Question(R.string.question_oceans,true),
            new Question(R.string.question_mideast,false),
            new Question(R.string.question_africa,false),
            new Question(R.string.question_americas,true),
            new Question(R.string.question_asia,true),
    };

    private int mCurrentIndex = 0;
    // create a boolean array to keep track of which questions have been answered
    private boolean[] mAnswered = new boolean[mQuestionBank.length];
    //keep count of how many questions have been answered
    private int mCount = 0;
    //keep track of how many questions the user correctly answered
    private int mScore = 0;

    private double mPercent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //calling Log.d(...) to log a message.
        Log.i(TAG,"OnCreate(Bundle) called");
        setContentView(R.layout.activity_main);

        mFalseButton = findViewById(R.id.false_button);
        mTrueButton = findViewById(R.id.true_button);
        mPrevButton = findViewById(R.id.prev_button);
        mNextButton = findViewById(R.id.next_button);

        if(savedInstanceState != null){
            //save current index of question after rotating screen
            mCurrentIndex=savedInstanceState.getInt(KEY_INDEX,0);
            mAnswered=savedInstanceState.getBooleanArray(QUESTION_ANSWERED);
        }


        mQuestionTextView = findViewById(R.id.question_text_view);
        updateQuestion();

        mQuestionTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentIndex = (mCurrentIndex+1)%mQuestionBank.length;
                updateQuestion();
            }
        });


        mTrueButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){



                /*Toast.makeText(MainActivity.this,
                        R.string.correct_toast,
                        Toast.LENGTH_SHORT).show();*/
                checkAnswer(true);
            }
        });


        mFalseButton.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                /*Toast.makeText(MainActivity.this,
                        R.string.incorrect_toast,
                        Toast.LENGTH_SHORT).show();*/
                checkAnswer(false);
            }
        });

        //code to customise the Toast. Use the setGravity method

        /*mTrueButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Toast toast = Toast.makeText(MainActivity.this,
                        R.string.correct_toast,
                        Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.TOP|Gravity.CENTER,0,0);
                toast.show();
            }
        });

        mFalseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast toast = Toast.makeText(MainActivity.this,
                        R.string.incorrect_toast,
                        Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.TOP|Gravity.CENTER,0,0);
                toast.show();
            }
        });*/


        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCurrentIndex = (mCurrentIndex+1)%mQuestionBank.length;
                //int question = mQuestionBank[mCurrentIndex].getTextResId();
                //mQuestionTextView.setText(question);
                updateQuestion();
            }
        });


        mPrevButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mCurrentIndex > 0) {
                    mCurrentIndex = (mCurrentIndex - 1) % mQuestionBank.length;
                } else {
                    mCurrentIndex = mQuestionBank.length-1;
                }
                updateQuestion();
            }
        });
    }
    //now overriding some more lifecycle callbacks
    @Override //This asks the compiler to ensure that the class actually has the method that you want to override.
    protected void onStart(){
        super.onStart(); // call to the superclass implementation before loggin
        Log.i(TAG,"onStart() called");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.i(TAG,"onResume() called");
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.i(TAG,"onPause() called");
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        Log.i(TAG, "onSaveInstanceState");
        savedInstanceState.putInt(KEY_INDEX, mCurrentIndex);
        savedInstanceState.putBooleanArray(QUESTION_ANSWERED,mAnswered);

    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.i(TAG,"onStop() called");
    }

    @Override
    protected
    void onDestroy(){
        super.onDestroy();
        Log.i(TAG,"onDestroy() called");
    }

    private void updateQuestion(){
        //Logging stack traces
        //Log.i(TAG, "Updating question text", new Exception());
        // toggle the buttons’ enabled state based on the question state
        mTrueButton.setEnabled(!mAnswered[mCurrentIndex]);
        mFalseButton.setEnabled(!mAnswered[mCurrentIndex]);
        int question =mQuestionBank[mCurrentIndex].getTextResId();
        mQuestionTextView.setText(question);
        //;
    }

    private void checkAnswer(boolean userPressedTrue) {
        boolean answerIsTrue = mQuestionBank[mCurrentIndex].isAnswerTrue();

        int messageResId;

        if (userPressedTrue == answerIsTrue){
            messageResId = R.string.correct_toast;
            mScore++;
        } else {
            messageResId = R.string.incorrect_toast;
        }
        //specify that the question in that position has been answered.
        mAnswered[mCurrentIndex] = true;
        mCount++;
        mTrueButton.setEnabled(false);
        mFalseButton.setEnabled(false);

        Toast.makeText(this,messageResId,Toast.LENGTH_SHORT).show();

        if(mCount == mQuestionBank.length){
            mPercent =((double)mScore/mCount)*100;
            String myToast = "You got "+mPercent;
            Toast.makeText(this,myToast,Toast.LENGTH_SHORT).show();
        }
    }
}
