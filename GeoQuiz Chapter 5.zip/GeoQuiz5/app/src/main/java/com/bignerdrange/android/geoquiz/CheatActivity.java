package com.bignerdrange.android.geoquiz;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CheatActivity extends AppCompatActivity {

    private static final String EXTRA_ANSWER_IS_TRUE ="com.bignerdranch.android.geoquiz.answer_is_true";
    private static final String EXTRA_ANSWER_SHOWN = "com.bignerdranch.android.geoquiz.answer_shown";
    private static final String KEY_INDEX_CHEAT = "key_index_cheat";

    //private boolean mIsAnswerShown = false;


    private boolean mAnswerTrue;
    private Button mShowAnswerButton;
    private TextView mAnswerTextView;

    //Instead, you can encapsulate that work into a newIntent(…) method.
    /*This static method allows you to create an Intent properly configured with the extras CheatActivity
    will need. The answerIsTrue argument, a boolean, is put into the intent with a private name using
    the EXTRA_ANSWER_IS_TRUE constant. You will extract this value momentarily. Using a newIntent(…)
    method like this for your activity subclasses will make it easy for other code to properly configure their
    launching intents*/
    public static Intent newIntent(Context packageContext, boolean answerTrue){
        Intent intent =new Intent(packageContext, CheatActivity.class);
        intent.putExtra(EXTRA_ANSWER_IS_TRUE, answerTrue);
        return intent;
    }

    // the contents of the result Intent are also an implementation detail of
    //CheatActivity, add another method to help decode the extra into something QuizActivity can use.
    public static boolean wasAnswerShown(Intent result){
        return result.getBooleanExtra(EXTRA_ANSWER_SHOWN,false);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cheat);

        if(savedInstanceState!=null){
            mAnswerTrue = savedInstanceState.getBoolean(KEY_INDEX_CHEAT,false);
            setAnswerShownResult(mAnswerTrue);
        }

        mShowAnswerButton = findViewById(R.id.show_answer_button);
        mAnswerTextView =findViewById(R.id.answer_text_view);

        //retrieve the value from the extra using the key and store it in a member variable
        //Note that Activity.getIntent() always returns the Intent that started the activity. This is what you
        //sent when calling startActivity(Intent).
        mAnswerTrue = getIntent().getBooleanExtra(EXTRA_ANSWER_IS_TRUE,false);

        mShowAnswerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mAnswerTrue) {
                    //You set the TextView’s text using TextView.setText(int).
                    mAnswerTextView.setText(R.string.true_button);
                } else {
                    mAnswerTextView.setText(R.string.false_button);
                }
                //When the user presses the SHOW ANSWER button, the CheatActivity packages up the result code
                //and the intent in the call to setResult(int, Intent).
                setAnswerShownResult(true);
                //mIsAnswerShown = true;

                //When the user presses the SHOW ANSWER button, the CheatActivity packages up the result code
                //and the intent in the call to setResult(int, Intent).
            }
        });

    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putBoolean(KEY_INDEX_CHEAT,mAnswerTrue);
    }

    private void setAnswerShownResult(boolean isAnswerShown){
        Intent data = new Intent();
        data.putExtra(EXTRA_ANSWER_SHOWN, isAnswerShown);
        setResult(RESULT_OK,data);
    }
}
